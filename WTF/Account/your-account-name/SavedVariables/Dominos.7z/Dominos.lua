
DominosDB = {
	["namespaces"] = {
		["ProgressBars"] = {
			["global"] = {
				["version"] = 1,
			},
			["profiles"] = {
				["Warrior"] = {
					["one_bar"] = true,
				},
				["Lucyon"] = {
					["one_bar"] = true,
				},
			},
		},
	},
	["profileKeys"] = {
		["Lûcyon - Bloodfeather"] = "Default",
		["Lucýon - Sylvanas"] = "Default",
		["Lucýon - Bloodfeather"] = "Default",
		["Lùcyon - Bloodfeather"] = "Default",
		["Lucyon - Bloodfeather"] = "Default",
		["Lucyón - Sylvanas"] = "Default",
		["Lucyón - Bloodfeather"] = "Default",
		["Lúcyon - Bloodfeather"] = "Default",
		["Lucykek - Bloodfeather"] = "Default",
		["Lucÿon - Bloodfeather"] = "Default",
		["Lucyón - The Maelstrom"] = "Default",
		["Lucyõn - Bloodfeather"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
			["linkedOpacity"] = true,
			["frames"] = {
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["scale"] = 1.1,
					["showInOverrideUI"] = false,
					["y"] = 47,
					["fadeAlpha"] = 0.3,
					["padW"] = 5,
					["spacing"] = 8,
					["padH"] = 5,
					["numButtons"] = 12,
					["pages"] = {
						["HUNTER"] = {
							["page2"] = 1,
							["page5"] = 4,
							["page4"] = 3,
							["page3"] = 2,
							["page6"] = 5,
						},
						["WARRIOR"] = {
							["page2"] = 1,
							["page5"] = 4,
							["page4"] = 3,
							["page3"] = 2,
							["page6"] = 5,
						},
						["ROGUE"] = {
							["page2"] = 1,
							["shadowdance"] = 6,
							["page5"] = 4,
							["page4"] = 3,
							["stealth"] = 6,
							["page3"] = 2,
							["page6"] = 5,
						},
						["MAGE"] = {
							["page2"] = 1,
							["page5"] = 4,
							["page4"] = 3,
							["page3"] = 2,
							["page6"] = 5,
						},
						["PRIEST"] = {
							["page2"] = 1,
							["page5"] = 4,
							["page4"] = 3,
							["page3"] = 2,
							["page6"] = 5,
						},
						["DEMONHUNTER"] = {
							["page2"] = 1,
							["page5"] = 4,
							["page4"] = 3,
							["page3"] = 2,
							["page6"] = 5,
						},
						["DRUID"] = {
							["bear"] = 8,
							["tree"] = 7,
							["page2"] = 1,
							["cat"] = 6,
							["page5"] = 4,
							["page4"] = 3,
							["moonkin"] = 9,
							["page3"] = 2,
							["page6"] = 5,
						},
						["MONK"] = {
							["page2"] = 1,
							["page5"] = 4,
							["page4"] = 3,
							["page3"] = 2,
							["page6"] = 5,
						},
						["PALADIN"] = {
							["page2"] = 1,
							["page5"] = 4,
							["page4"] = 3,
							["page3"] = 2,
							["page6"] = 5,
						},
					},
					["showstates"] = "[combat]100;",
				}, -- [1]
				{
					["showInPetBattleUI"] = false,
					["point"] = "TOPRIGHT",
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["padW"] = 2,
					["x"] = -274,
					["spacing"] = 4,
					["padH"] = 2,
					["numButtons"] = 12,
					["pages"] = {
						["HUNTER"] = {
						},
						["WARRIOR"] = {
						},
						["ROGUE"] = {
						},
						["MAGE"] = {
						},
						["PRIEST"] = {
						},
						["DEMONHUNTER"] = {
						},
						["DRUID"] = {
						},
						["MONK"] = {
						},
						["PALADIN"] = {
						},
					},
					["y"] = -223,
				}, -- [2]
				{
					["showInPetBattleUI"] = false,
					["columns"] = 1,
					["scale"] = 0.75,
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["y"] = -149,
					["showstates"] = "",
					["numButtons"] = 12,
					["spacing"] = 4,
					["padH"] = 2,
					["fadeAlpha"] = 0,
					["pages"] = {
						["HUNTER"] = {
						},
						["WARRIOR"] = {
						},
						["ROGUE"] = {
						},
						["MAGE"] = {
						},
						["PRIEST"] = {
						},
						["DEMONHUNTER"] = {
						},
						["DRUID"] = {
						},
						["MONK"] = {
						},
						["PALADIN"] = {
						},
					},
					["point"] = "RIGHT",
				}, -- [3]
				{
					["showInPetBattleUI"] = false,
					["columns"] = 1,
					["point"] = "RIGHT",
					["scale"] = 0.75,
					["showInOverrideUI"] = false,
					["numButtons"] = 12,
					["y"] = -149,
					["fadeAlpha"] = 0,
					["padW"] = 2,
					["spacing"] = 4,
					["padH"] = 2,
					["x"] = -40,
					["pages"] = {
						["HUNTER"] = {
						},
						["WARRIOR"] = {
						},
						["ROGUE"] = {
						},
						["MAGE"] = {
						},
						["PRIEST"] = {
						},
						["DEMONHUNTER"] = {
						},
						["DRUID"] = {
						},
						["MONK"] = {
						},
						["PALADIN"] = {
						},
					},
					["showstates"] = "",
				}, -- [4]
				{
					["showInPetBattleUI"] = false,
					["columns"] = 6,
					["scale"] = 0.9,
					["showInOverrideUI"] = false,
					["padW"] = 3,
					["fadeAlpha"] = 0.3,
					["showstates"] = "[combat]100;",
					["spacing"] = 10,
					["padH"] = 3,
					["numButtons"] = 12,
					["pages"] = {
						["HUNTER"] = {
						},
						["WARRIOR"] = {
						},
						["ROGUE"] = {
						},
						["MAGE"] = {
						},
						["PRIEST"] = {
						},
						["DEMONHUNTER"] = {
						},
						["DRUID"] = {
						},
						["MONK"] = {
						},
						["PALADIN"] = {
						},
					},
					["point"] = "BOTTOMRIGHT",
				}, -- [5]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["scale"] = 1,
					["showInOverrideUI"] = false,
					["padW"] = 5,
					["showstates"] = "",
					["padH"] = 5,
					["spacing"] = 8,
					["anchor"] = "1BC",
					["numButtons"] = 12,
					["pages"] = {
						["HUNTER"] = {
						},
						["WARRIOR"] = {
						},
						["ROGUE"] = {
						},
						["MAGE"] = {
						},
						["PRIEST"] = {
						},
						["DEMONHUNTER"] = {
						},
						["DRUID"] = {
						},
						["MONK"] = {
						},
						["PALADIN"] = {
						},
					},
					["y"] = 6,
				}, -- [6]
				{
					["showInPetBattleUI"] = false,
					["point"] = "RIGHT",
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["padW"] = 2,
					["x"] = -274,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 137,
					["numButtons"] = 12,
					["pages"] = {
						["HUNTER"] = {
						},
						["WARRIOR"] = {
						},
						["ROGUE"] = {
						},
						["MAGE"] = {
						},
						["PRIEST"] = {
						},
						["DEMONHUNTER"] = {
						},
						["DRUID"] = {
						},
						["MONK"] = {
						},
						["PALADIN"] = {
						},
					},
				}, -- [7]
				{
					["showInPetBattleUI"] = false,
					["point"] = "RIGHT",
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["padW"] = 2,
					["x"] = -274,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 177,
					["pages"] = {
						["HUNTER"] = {
						},
						["WARRIOR"] = {
						},
						["ROGUE"] = {
						},
						["MAGE"] = {
						},
						["PRIEST"] = {
						},
						["DEMONHUNTER"] = {
						},
						["DRUID"] = {
						},
						["MONK"] = {
						},
						["PALADIN"] = {
						},
					},
					["numButtons"] = 12,
				}, -- [8]
				{
					["showInPetBattleUI"] = false,
					["point"] = "RIGHT",
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["padW"] = 2,
					["x"] = -274,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 217,
					["numButtons"] = 12,
					["pages"] = {
						["HUNTER"] = {
						},
						["WARRIOR"] = {
						},
						["ROGUE"] = {
						},
						["MAGE"] = {
						},
						["PRIEST"] = {
						},
						["DEMONHUNTER"] = {
						},
						["DRUID"] = {
						},
						["MONK"] = {
						},
						["PALADIN"] = {
						},
					},
				}, -- [9]
				{
					["showInPetBattleUI"] = false,
					["point"] = "RIGHT",
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["padW"] = 2,
					["x"] = -274,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 257,
					["numButtons"] = 12,
					["pages"] = {
						["HUNTER"] = {
						},
						["WARRIOR"] = {
						},
						["ROGUE"] = {
						},
						["MAGE"] = {
						},
						["PRIEST"] = {
						},
						["DEMONHUNTER"] = {
						},
						["DRUID"] = {
						},
						["MONK"] = {
						},
						["PALADIN"] = {
						},
					},
				}, -- [10]
				["artifact"] = {
					["showInPetBattleUI"] = false,
					["point"] = "TOP",
					["columns"] = 20,
					["numButtons"] = 20,
					["padW"] = 2,
					["lockMode"] = true,
					["padH"] = 2,
					["font"] = "Friz Quadrata TT",
					["y"] = -16,
					["x"] = 0,
					["showInOverrideUI"] = false,
					["spacing"] = 1,
					["display"] = {
						["value"] = true,
						["bonus"] = true,
						["max"] = true,
						["label"] = true,
					},
					["mode"] = "artifact",
					["alwaysShowText"] = true,
					["texture"] = "blizzard",
				},
				["exp"] = {
					["showInPetBattleUI"] = false,
					["point"] = "TOP",
					["columns"] = 20,
					["numButtons"] = 20,
					["padW"] = 2,
					["lockMode"] = true,
					["padH"] = 2,
					["font"] = "Friz Quadrata TT",
					["y"] = 0,
					["x"] = 0,
					["showInOverrideUI"] = false,
					["spacing"] = 1,
					["display"] = {
						["value"] = true,
						["bonus"] = true,
						["max"] = true,
						["label"] = true,
					},
					["mode"] = "xp",
					["alwaysShowText"] = true,
					["texture"] = "blizzard",
				},
				["encounter"] = {
					["showInPetBattleUI"] = true,
					["showInOverrideUI"] = true,
					["scale"] = 1,
				},
				["bags"] = {
					["showInPetBattleUI"] = false,
					["x"] = 285,
					["point"] = "TOP",
					["spacing"] = 2,
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["y"] = -193,
				},
				["pet"] = {
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["scale"] = 1,
					["showInOverrideUI"] = false,
					["y"] = 102,
					["x"] = 112,
					["spacing"] = 6,
					["padH"] = 3,
					["padW"] = 3,
				},
				["alerts"] = {
					["showInPetBattleUI"] = true,
					["point"] = "LEFT",
					["spacing"] = 2,
					["showInOverrideUI"] = true,
					["columns"] = 1,
				},
				["menu"] = {
					["showInPetBattleUI"] = false,
					["fadeAlpha"] = 0,
					["point"] = "BOTTOMRIGHT",
					["spacing"] = 0,
					["scale"] = 0.75,
					["showInOverrideUI"] = false,
					["x"] = -438,
				},
				["cast"] = {
					["showInPetBattleUI"] = false,
					["point"] = "CENTER",
					["showInOverrideUI"] = false,
					["y"] = 30,
					["font"] = "Friz Quadrata TT",
					["display"] = {
						["border"] = true,
						["time"] = true,
						["icon"] = false,
					},
					["padH"] = 1,
					["x"] = 0,
					["padW"] = 1,
					["texture"] = "blizzard",
				},
				["extra"] = {
					["y"] = 141,
					["x"] = -3,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["showInPetBattleUI"] = false,
				},
				["vehicle"] = {
					["y"] = 102,
					["x"] = -276,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["showInPetBattleUI"] = false,
				},
				["roll"] = {
					["showInPetBattleUI"] = true,
					["point"] = "LEFT",
					["spacing"] = 2,
					["showInOverrideUI"] = true,
					["columns"] = 1,
				},
				["class"] = {
					["showInPetBattleUI"] = false,
					["x"] = -244,
					["point"] = "BOTTOM",
					["spacing"] = 2,
					["showInOverrideUI"] = false,
					["y"] = 102,
				},
			},
			["minimap"] = {
				["hide"] = true,
			},
			["showgrid"] = false,
		},
		["3 stacked"] = {
			["frames"] = {
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["scale"] = 1,
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["showstates"] = "",
					["padH"] = 2,
					["spacing"] = 4,
					["anchor"] = "6TL",
					["pages"] = {
						["MAGE"] = {
							["page2"] = 1,
							["page5"] = 4,
							["page4"] = 3,
							["page3"] = 2,
							["page6"] = 5,
						},
						["WARRIOR"] = {
							["page2"] = 1,
							["page5"] = 4,
							["page4"] = 3,
							["page3"] = 2,
							["page6"] = 5,
						},
						["PALADIN"] = {
							["page2"] = 1,
							["page5"] = 4,
							["page4"] = 3,
							["page3"] = 2,
							["page6"] = 5,
						},
					},
					["numButtons"] = 12,
					["y"] = 80,
				}, -- [1]
				{
					["showInPetBattleUI"] = false,
					["point"] = "RIGHT",
					["scale"] = 1,
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["padW"] = 2,
					["x"] = -173,
					["padH"] = 2,
					["spacing"] = 4,
					["anchor"] = "7BC",
					["pages"] = {
						["MAGE"] = {
						},
						["WARRIOR"] = {
						},
						["PALADIN"] = {
						},
					},
					["numButtons"] = 12,
					["y"] = -160,
				}, -- [2]
				{
					["showInPetBattleUI"] = false,
					["point"] = "RIGHT",
					["scale"] = 1,
					["showInOverrideUI"] = false,
					["columns"] = 1,
					["padW"] = 2,
					["showstates"] = "",
					["pages"] = {
						["MAGE"] = {
						},
						["WARRIOR"] = {
						},
						["PALADIN"] = {
						},
					},
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = -31,
					["numButtons"] = 12,
					["fadeAlpha"] = 0,
				}, -- [3]
				{
					["showInPetBattleUI"] = false,
					["point"] = "RIGHT",
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["padW"] = 2,
					["x"] = -173,
					["padH"] = 2,
					["spacing"] = 4,
					["anchor"] = "10TL",
					["pages"] = {
						["MAGE"] = {
						},
						["WARRIOR"] = {
						},
						["PALADIN"] = {
						},
					},
					["numButtons"] = 12,
					["y"] = 40,
				}, -- [4]
				{
					["showInPetBattleUI"] = false,
					["pages"] = {
						["MAGE"] = {
						},
						["WARRIOR"] = {
						},
						["PALADIN"] = {
						},
					},
					["point"] = "BOTTOM",
					["spacing"] = 4,
					["padH"] = 2,
					["showInOverrideUI"] = false,
					["numButtons"] = 12,
					["padW"] = 2,
				}, -- [5]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["y"] = 40,
					["padH"] = 2,
					["spacing"] = 4,
					["anchor"] = "5TC",
					["pages"] = {
						["MAGE"] = {
						},
						["WARRIOR"] = {
						},
						["PALADIN"] = {
						},
					},
					["numButtons"] = 12,
					["padW"] = 2,
				}, -- [6]
				{
					["showInPetBattleUI"] = false,
					["point"] = "RIGHT",
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["padW"] = 2,
					["x"] = -165,
					["padH"] = 2,
					["spacing"] = 4,
					["anchor"] = "8BC",
					["pages"] = {
						["MAGE"] = {
						},
						["WARRIOR"] = {
						},
						["PALADIN"] = {
						},
					},
					["numButtons"] = 12,
					["y"] = -13,
				}, -- [7]
				{
					["showInPetBattleUI"] = false,
					["point"] = "RIGHT",
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["padW"] = 2,
					["x"] = -169,
					["padH"] = 2,
					["spacing"] = 4,
					["anchor"] = "9BC",
					["pages"] = {
						["MAGE"] = {
						},
						["WARRIOR"] = {
						},
						["PALADIN"] = {
						},
					},
					["numButtons"] = 12,
					["y"] = 13,
				}, -- [8]
				{
					["showInPetBattleUI"] = false,
					["point"] = "RIGHT",
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["padW"] = 2,
					["x"] = -169,
					["padH"] = 2,
					["spacing"] = 4,
					["anchor"] = "10BR",
					["pages"] = {
						["MAGE"] = {
						},
						["WARRIOR"] = {
						},
						["PALADIN"] = {
						},
					},
					["numButtons"] = 12,
					["y"] = -40,
				}, -- [9]
				{
					["showInPetBattleUI"] = false,
					["point"] = "RIGHT",
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["padW"] = 2,
					["x"] = -173,
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["MAGE"] = {
						},
						["WARRIOR"] = {
						},
						["PALADIN"] = {
						},
					},
					["numButtons"] = 12,
				}, -- [10]
				["artifact"] = {
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["columns"] = 20,
					["numButtons"] = 20,
					["padW"] = 2,
					["lockMode"] = true,
					["hidden"] = true,
					["padH"] = 2,
					["y"] = 145,
					["font"] = "Friz Quadrata TT",
					["showInOverrideUI"] = false,
					["spacing"] = 1,
					["display"] = {
						["value"] = true,
						["bonus"] = true,
						["max"] = true,
						["label"] = true,
					},
					["mode"] = "artifact",
					["alwaysShowText"] = true,
					["texture"] = "blizzard",
				},
				["menu"] = {
					["showInPetBattleUI"] = false,
					["x"] = -338,
					["point"] = "BOTTOMRIGHT",
					["spacing"] = 0,
					["scale"] = 1,
					["showInOverrideUI"] = false,
					["fadeAlpha"] = 0,
				},
				["exp"] = {
					["point"] = "BOTTOM",
					["scale"] = 1,
					["lockMode"] = true,
					["padW"] = 2,
					["fadeAlpha"] = 0,
					["spacing"] = 1,
					["anchor"] = "1TC",
					["mode"] = "xp",
					["numButtons"] = 20,
					["texture"] = "Minimalist",
					["showInPetBattleUI"] = false,
					["columns"] = 20,
					["showInOverrideUI"] = false,
					["width"] = 471,
					["y"] = 120,
					["font"] = "Friz Quadrata TT",
					["height"] = 12,
					["padH"] = 2,
					["display"] = {
						["value"] = true,
						["bonus"] = true,
						["max"] = true,
						["label"] = true,
					},
					["alwaysShowText"] = true,
				},
				["extra"] = {
					["showInPetBattleUI"] = false,
					["showInOverrideUI"] = false,
					["point"] = "BOTTOM",
					["y"] = 197,
				},
				["bags"] = {
					["showInPetBattleUI"] = false,
					["x"] = 386,
					["spacing"] = 2,
					["anchor"] = "2BL",
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["y"] = -235,
				},
				["pet"] = {
					["y"] = -249,
					["x"] = 45,
					["point"] = "LEFT",
					["spacing"] = 6,
					["showInOverrideUI"] = false,
					["showInPetBattleUI"] = false,
				},
				["vehicle"] = {
					["y"] = 45,
					["x"] = -282,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["showInPetBattleUI"] = false,
				},
			},
			["minimap"] = {
				["minimapPos"] = 54.4623132124895,
			},
		},
	},
}
DominosVersion = "7.3.2"
